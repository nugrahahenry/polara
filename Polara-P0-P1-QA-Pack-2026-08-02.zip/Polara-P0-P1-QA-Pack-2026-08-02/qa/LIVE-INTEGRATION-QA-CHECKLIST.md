# P0 + P1 Live Integration QA Checklist

This checklist is the remaining gate after the combined asset-level QA.

## Registry and loading

- [ ] Merge `registry-ready-combined.json` into `src/modules/stickers/index.js`.
- [ ] Confirm all 17 runtime paths resolve with no 404.
- [ ] Load only files from `assets/mascot/` and `assets/stickers/`.
- [ ] Exclude `_originals/`, `qa/`, and `review/` from the client runtime.
- [ ] Preserve intrinsic aspect ratio with `object-fit: contain`.

## Tray and scrolling

Test at 320, 360, 390, 430, 768, 1024, and 1440 CSS px.

- [ ] Tray item visual size is approximately 54 px.
- [ ] Touch target is at least 44 × 44 CSS px.
- [ ] First and last asset can be reached without clipping.
- [ ] End padding remains visible after scrolling to the final asset.
- [ ] Horizontal tray does not create page-level horizontal overflow.
- [ ] Keyboard focus can reach every asset.
- [ ] The focused item is not hidden behind a sticky dock or safe-area inset.
- [ ] `photo-buddy-badge` has an external text label; do not rely on its internal copy at 54 px.

## Canvas placement and photo-first behavior

- [ ] New stickers start away from the central face/photo focal region.
- [ ] Poca is a helper/corner accent, not the largest element on the photo.
- [ ] Asset aspect ratio never changes during resize.
- [ ] Drag, resize, rotate, delete, undo, and reset work with touch and pointer.
- [ ] Selection handles do not become part of export.
- [ ] Stickers can be moved fully back into the safe area if dragged near an edge.
- [ ] Large `poca-face` placement is not offered; keep it to compact contexts.
- [ ] Avoid stacking multiple richly shaded P1 assets at large scale on one photo.

## Transparent frame

- [ ] A live user photo is visible through `poca-holding-photo-frame`.
- [ ] No opaque backing layer accidentally fills the frame opening.
- [ ] The frame and photo remain aligned through resize and rotation.
- [ ] Export preserves transparency/compositing and does not create a white rectangle.

## State and regression

- [ ] Sticker state survives back/forward navigation in the editor flow.
- [ ] Retaking one strip slot does not remove placed stickers or other photos.
- [ ] Camera denied/unavailable and export-error states do not corrupt asset state.
- [ ] Share cancellation returns to the same reveal state.
- [ ] Reduced-motion mode still communicates selection and placement state.
- [ ] PNG export matches the on-screen composition on mobile and desktop.

## Final acceptance

- [ ] Run on at least one iOS Safari device, one Android Chrome device, and desktop Chrome/Firefox/Safari.
- [ ] Dogfood with 3–5 people and record whether they can find the final tray item and successfully share.
